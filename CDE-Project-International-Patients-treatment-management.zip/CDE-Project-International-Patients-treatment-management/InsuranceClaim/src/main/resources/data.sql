insert into insurer_detail (id, insurer_name, insurer_package_name, insurer_package_amount_limit, disbursement_duration) values (1, 'Apollo Munich', 'Surgical Protection', 16442, 3);
insert into insurer_detail (id, insurer_name, insurer_package_name, insurer_package_amount_limit, disbursement_duration) values (2, 'Max Rupa', 'Health Companion Family Floater', 15194, 4);
insert into insurer_detail (id, insurer_name, insurer_package_name, insurer_package_amount_limit, disbursement_duration) values (3, 'Star Health', 'Extra Care', 25460, 5);
insert into insurer_detail (id, insurer_name, insurer_package_name, insurer_package_amount_limit, disbursement_duration) values (4, 'Policy Bazaar', 'Critical Illness', 15200, 2);
insert into insurer_detail (id, insurer_name, insurer_package_name, insurer_package_amount_limit, disbursement_duration) values (5, 'Religare', 'Silver Health Plan for Senior Citizens', 45975, 6);
   