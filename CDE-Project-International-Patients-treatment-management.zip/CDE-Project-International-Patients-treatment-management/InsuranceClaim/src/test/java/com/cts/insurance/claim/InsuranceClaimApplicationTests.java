package com.cts.insurance.claim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceClaimApplicationTests {
	@Test
	void main() {
		InsuranceClaimApplication.main(new String[] {});
	}
}
