package com.cts.iptreatment.model;

import lombok.ToString;

@ToString
public enum AilmentCategory {

	ORTHOPAIDICS,
	UROLOGY
}
