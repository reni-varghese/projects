package com.cts.iptreatment.exception;
@SuppressWarnings("serial")
public class IPTreatmentPackageNotFoundException extends Exception{

	public IPTreatmentPackageNotFoundException(String message) {
		
		super(message);
	}
}
