package com.cts.iptreatment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpTreatmentMicroServiceApplicationTests {

	@Test
	public void main() {
		IpTreatmentMicroServiceApplication.main(new String[] {});
	}
}
