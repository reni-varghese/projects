package com.payment.microservice.exception;

public class InvalidFormatException extends RuntimeException{
	
	public InvalidFormatException(String message) {
		super(message);
	}


}
